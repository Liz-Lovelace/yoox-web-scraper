В файле вся женская обувь с yoox.com

Всего 65280 элементов, всё соответствует JSON формату ABAi.

Заполненные поля:
  id
  category_id
  parent_category_id
  product_url
  image_url
  
Не заполнены:
  group_id
  available

Контакты:
  github/telgram - Mishanya644
  email          - ivanov0604041@gmail.com